PAIN & REGRET STUDIO
=====================

This is a complete static website.

Files:
- index.html  = the website
- artist.jpg  = the studio image

To publish it with GitHub Pages:
1. Create/open your GitHub repository.
2. Upload BOTH index.html and artist.jpg to the repository's main branch.
3. Open Settings -> Pages.
4. Under "Build and deployment", choose "Deploy from a branch".
5. Choose the main branch and the /(root) folder, then Save.
6. Wait a minute or two. GitHub will show your website link on the Pages screen.
7. Send that link to your friend.

The website works on phones and computers. The answers are clickable and only one
answer can be selected per question. The final screen displays the choices he made.

If you rename artist.jpg, update the image filename in index.html too.
